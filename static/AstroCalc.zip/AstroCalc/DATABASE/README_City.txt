Format fichier city.csv
Ville;Latitude_deg;Latitude_min;Latitude_sec;N/S;Longitude_deg;Longitude_min;Longiude_sec;E/W

Attention si vous editez directement le fichier city.csv avec un editeur de texte
respecter bien le format typ� du fichier :

* : position du curseur � la sauvegarde du fichier

exemple :

Ajaccio;41;55;0;N;8;44;15;E
Amiens;49;54;0;N;2;18;15;E
Angers;47;28;0;N;0;33;15;W
Bastia;42;42;0;N;9;27;15;E
Besan�on;47;14;0;N;6;1;30;E
Bordeaux;44;50;0;N;0;34;30;W
Brest;48;23;0;N;4;29;15;W
Caen;49;11;0;N;0;22;15;W
*

