######################
   AstroCalc v3.20 
par Guillaume BERTRAND 
######################

derni�re maj : Mars 2007
											 											 
---------------------------------------------------
Historique des Versions
---------------------------------------------------

Nouveaut�s de la version 3.20 >>>>> 17/03/2007 :
-Mise � jour de CroTool (version 4.1)
	*Nouveaux modules de calcul
	*Possibilit� de recherche
	*Possibilit� de dupliquer un enregistrement
	*Nouvelle possibilit� d'exportation (HTML, TXT format�)
	*Possibilit� de joindre un fichier image.
-Correction de plusieurs bugs d'AstroCalc v3.1
-MAJ Fichier cometes.txt

Nouveaut�s de la version 3.10 >>>>> 03/01/2007 :
-Mise � jour de CroTool (version 4)
-Traduction en Espagnol (Isaac Lozano Rey)
-Traduction en Russe et Ukrainien (Oleg Maliy)
-Mise � jour du composant Glscene permettant l'affichage 3D des plan�tes
-Correction de bugs mineurs....

Nouveaut�s de la version 3.00 >>>>> 28/10/2006 :
-Satellites de Mars et de Saturne.
-Calcul des librations lunaire
-Angle de position Mercure et V�nus
-Possiblit� de ��mapper�� les plan�tes avec n'importe quelles textures
-Possibilit� de cr�er des vid�o *.avi d'animation des plan�tes 
-Nouvel Affichage ��Position h�liocentrique des plan�tes��
-Am�lioration de la pr�cision des horaires de lever/passage/coucher
-Correction bugs mineurs etc....

Nouveaut�s de la version 2.90 >>>>> 30/07/2006 :
-Nouvelle Traduction en Allemand (Traduction Stefan Neumann)
-Am�lioration Affichage des noms des satellites de Jupiter
(survoler un des satellites pour que le nom s'affiche)
-Ajout de ville dans la base de donn�es city.csv
-Correction bugs mineurs

Nouveaut�s de la version 2.84 >>>>> 13/07/2006 :
-Nouvelle version CroTool v3.3 (deux langues Anglais/Fran�ais)
-Correction bugs mineurs CroTool et AstroCalc

Nouveaut�s de la version 2.83 >>>>> 06/07/2006 :
-Correction bug mineur (utilisation du presse papier)
-Correction version anglaise
-MAJ de l'aide d'AstroCalc

Nouveaut�s de la version 2.82 >>>>> 30/06/2006 :
-Possibilit�s de choisir l'orientation de l'image (sud ou nord en haut)
-Correction de quelques bugs sur la version anglaise

Nouveaut�s de la version 2.81 >>>>> 21/06/2006 :
-Correction bugs de la version 2.8
-Ajout de ville dans la base de donn�es city.csv
-Nouvelle map venus,saturne
-Correction de quelques bugs sur la version anglaise

Nouveaut�s de la version 2.8 >>>>> 16/06/2006 :
-Deux langues dispo. Fran�ais et Anglais
-Ajout M�ridien central Syst I, Syst II (Atm. UV) pour v�nus
-Ajout M�ridien central Syst I pour mercure.
-Correction bugs mineurs
-Nouveau module "G�n�rateur d'Eph�m�rides"
-Nouvelle map Jupiter, Mars

Nouveaut�s de la version 2.7 >>>>> 24/05/2006 :
-Correction bugs mineurs,
-Ajout de la Hauteur des plan�tes
-Nouveaut�s dans CroTool v3.2
	-Base de donn�e d'objet du ciel profond (pour importer : cliquez droit dans zone "Observation")
	-Correction Bug d'importation depuis AstroCalc.


Nouveaut�s de la version 2.61 >>>>> 28/04/2006 :
-Correction bugs mineurs,
-Integration de l'utilitaire CroTool v3.1 "Gestionnaire de CROA"


Nouveaut�s de la version 2.50 >>>>> 14/04/2006 :
-Ajout d'une aide D�taill�e.
-Am�lioration du module de configuration
-Ajout M�ridien central syst I,II,III pour Saturne,
-Ajout M�ridien central syst I,II,III pour Jupiter,
-Excentricit� des orbites dans le graph Pos. H�liocentrique
-Possibilit� de mise � jour auto des El�ments des Com�tes/Ast�ro�des 
-Corection des bugs de dates.
-Et encore beaucoup d'autres nouveaut�es...

Nouveaut�s de la version 2.00 >>>>> 28/02/2006 :
-Correction de plusieurs bugs mineurs.
-Am�lioration du graphisme du module "Affichage de la position des plan�tes sur l'�cliptique".
-Module de Configuration plus complet, possibillit� de d�sativ� les ombres sur les plan�tes etc...
-Nouveau Module Calcul d'�ph�merides pour les Com�tes...

Nouveaut�s de la version 1.70 >>>>> 09/02/2006 :
-Ajout des Satellites de jupiter et de leurs ombres sur jupiter,
-Simulation de l'Ombre du globe de Saturne sur les anneaux.
-Am�lioration du module 'Fichier de r�sultats'.

Nouveaut�s de la verion 1.61 >>>>> 26/01/2006 :
-Am�lioration et Correction des bugs dans le module de configuration,
-Plein d'autres nouveaut�s...

Nouveaut�s de la verion 1.52 >>>>> 14/01/2006 :
-Am�lioration de la pr�cision des horaires de lever,
passage,coucher des plan�tes

Nouveaut�s de la verion 1.51 >>>>> 13/01/2006 :
-Correction de quelques bug d'affichage.
-Am�lioration du module de configuration.

Nouveaut�s de la verion 1.50 >>>>> 7/01/2006 :
-Nouvelle Apparence StyleXP sp�cial.....
-Simulation de l'Apparence de Saturne.

Nouveaut�s de la verion 1.33 >>>>> 3/01/2006 :
-Correction d'un bug mineur....

Nouveaut�s de la verion 1.32 >>>>> 14/12/2005 :
-Nouvelle version du composant GLscene utilis� pour l'affichage des plan�tes
pour une meilleur compatibilit�.

Nouveaut�s de la version 1.31 >>>> 1/12/2005 :
-Ajouts de deux nouveaux modules :
-->Calcul des heures de passage au m�ridien de la GTR sur Jupiter
-->Possibilit� de g�n�rer un fichier de r�sultats contenant tous les param�tres calcul� par AstroCalc. 

Nouveaut�s de la version 1.200 >>>> 11/11/2005 :
-Visualisation Graphique R�aliste de l'apparence de Mars

Nouveaut�s de la version 1.100 >>>> 11/11/2005 :
-Visualisation Graphique R�aliste de Mercure,V�nus et Jupiter...
-Am�lioration de l'interface d'AstroCalc

Nouveaut�s de la version 1.095 >>>> 1/11/2005 :
-Possibilit� de choisir une ville (longitude et latitude rentr�es automatiquement en fonction de la ville choisie). Pour l'instant que quelques villes de France dispo.

Nouveaut�s de la version 1.09 >>>> 31/10/2005 :
-Am�lioration de l'interface
-Affichage de la position H�liocentrique des plan�tes
-Affichage de la position des plan�tes sur l'�cliptique

Nouveaut�s de la version 1.08 >>>> 27/10/2005 :
-Calcul des coordonn�es de Saturne
-Nouveau graph de visualisation de la pos. de la GTR 



�2006 Guillaume BERTRAND 